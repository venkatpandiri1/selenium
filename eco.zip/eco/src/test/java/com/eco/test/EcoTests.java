package com.eco.test;
import org.testng.Assert;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.eco.base.dataReaderFromExcel;
import com.eco.utils.AppProperties;


import java.util.Properties;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class EcoTests {
	
		private WebDriver driver;
		private AppProperties appProp;
		public static Properties appProperties;
		public static WebDriverWait wait;
		public static boolean bresult = false;
		
		dataReaderFromExcel dtRdr;
		
		String timeStamp = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new Date());
		
		//@Test (priority =1)
		public void HomePage() {
			System.out.println("Entering home page method");
			Reporter.log(timeStamp + " Entering home page method."+ "<br>");
		    //driver.get("http://www.google.com");
		    driver.get("https://eco.test.att.com/uui/landing");
		    
		    wait = new WebDriverWait(driver, 30);
		  	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("login")));
		    wait = new WebDriverWait(driver, 30);
		    if(driver.findElements(By.id("login")).size() > 0) {
		    	Assert.assertTrue(true);
		    }
		    else Assert.assertTrue(false);
					
			System.out.println("End of the homepage method");
			Reporter.log(timeStamp + " End of the homepage method."+ "<br>");
		}
		
		
		@Test (priority = 2)
		public void login() throws IOException {
			System.out.println("Entering login method");
			Reporter.log(timeStamp + " Entering login method."+ "<br>");
		    //driver.get("http://www.google.com");
		   
		    /*WebElement login = driver.findElement(By.id("login"));
		    login.click();
			
		    wait = new WebDriverWait(driver, 30);
		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("userid"))); */
		
		    AppProperties ap = new AppProperties();
			Properties appProperties = ap.getProperties();
		    
		   
		   // System.out.println(appProperties.getProperty("username"));
		   //	System.out.println(appProperties.getProperty("password"));
		   	dtRdr = new dataReaderFromExcel(); 
		    
		   	List<String> strList; 
		   	List<String> strListValues;
		   	
			strList = dtRdr.readXLSFile();
			strListValues = dtRdr.readXLSFileValues();
			
		    System.out.println("Row 1 "+ appProperties.getProperty(strList.get(0)));
		    System.out.println("Row 2 "+ appProperties.getProperty(strList.get(1)));
		    System.out.println("Row 3 "+ appProperties.getProperty(strList.get(2)));
		    
		    
		    System.out.println("Row 1 strListValues "+ strListValues.get(0));
		    System.out.println("Row 2 strListValues "+ strListValues.get(1));
		    System.out.println("Row 3  strListValues "+ strListValues.get(2));
		    System.out.println("-----------------------------------------");
		    
		    driver.findElement(By.name(appProperties.getProperty(strList.get(0)))).sendKeys(strListValues.get(0));
		    driver.findElement(By.name(appProperties.getProperty(strList.get(1)))).sendKeys(strListValues.get(1));
		    driver.findElement(By.name(appProperties.getProperty(strList.get(2)))).click();
		    
		    //check for the success login screen
		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("srv_TitleMsg")));
		  
		   if (driver.findElement(By.id("srv_TitleMsg")).getText().compareTo("Log On Successful") == 0)
		   {
			   System.out.println("succesfully logged in");
		   }
		   
		    driver.findElement(By.name("successOK")).click();
		    
		    wait = new WebDriverWait(driver, 10);
		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("module-header")));
		    
		    if (driver.findElement(By.id("module-header")).getText().compareTo(" Deployment Pipeline") == 0) {
		    	 {
		  		   System.out.println("succesfully navigated to pipeline page in");
		  	   }
		    }
		    		    
		    
			System.out.println("End of the login method");
			Reporter.log(timeStamp + "End of the login method."+ "<br>");
		}
		
		
		/**
		 * create pipeline test
		 */
		
		
		@Test(priority = 3)
		public void createPipeline()
		{
			if (driver.findElements(By.className("btn btn-xs btn-primary pull-right createBtn")).size() > 0)
			{
				Reporter.log(timeStamp + "Found the create pipeline link."+ "<br>");
			}
			
		}
		
		
		
		@Test (priority = 10)
		public void exit() {
			System.out.println("Entering exit method");
			//WebDriver driver = new FirefoxDriver();
			//driver.get("http://www.google.com");
			driver.close();
			driver.quit();
			System.out.println("End of the exit method");
		}
		
		
		 @BeforeTest
		  public void beforeTest() throws Exception  {  
			  //Create chrome driver
			  try{
			 // System.out.println("Root folder = "+System.getProperty("user.dir"));
			  
			 System.setProperty("webdriver.chrome.driver", "C:\\Users\\vp1515\\Downloads\\chromedriver_win32\\chromedriver.exe");
			  driver = new ChromeDriver();
			  
			  getConfigurationData();
			  
			  }
		  
		  catch(Exception ex)
		  {
			  System.out.println("Error is " + ex.toString());
		  }

			  
		  
		  }
		 
		 public void getConfigurationData() {
			  appProp = new AppProperties();
			  appProperties = appProp.getProperties();
			  //env =appProp.getProperty("username");
		 }
		 
		
		  


}
