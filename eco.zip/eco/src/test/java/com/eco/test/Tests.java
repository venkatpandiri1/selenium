package com.eco.test;
import com.eco.base.*;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import java.lang.*;

public class Tests{
  WebDriver driver;
  public static WebDriverWait wait;
  
  @Test (priority = 1)
  public void homePage() {
	    
	  driver.get("https://eco.dev.att.com/uui/landing");
	  System.out.println("Opened the home page");
	  wait = new WebDriverWait(driver, 30);
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("login")));
  }
  
  
  
  @Test (priority = 2)
	public void login() {
		System.out.println("Entering login method");
	    
	   
	    WebElement login = driver.findElement(By.id("login"));
	    login.click();
		
	    wait = new WebDriverWait(driver, 30);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("userid")));
	    
	    driver.findElement(By.name("userid")).sendKeys("vp1515");
	    driver.findElement(By.name("password")).sendKeys("Vamshi#1");
	    driver.findElement(By.name("password")).sendKeys("btnSubmit");
	    
	    
		System.out.println("End of the login method");
	}
    
  @BeforeTest
  public void beforeTest(String drType) {	  
	  Drivers drs = new Drivers();
	  driver = drs.getChormeDriver(); 
  }

  @AfterTest
  public void afterTest() {
  }

}
