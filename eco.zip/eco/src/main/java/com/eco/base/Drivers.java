package com.eco.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class Drivers {
	static WebDriver driver;
	
	public WebDriver getChormeDriver() {
		  System.setProperty("webdriver.chrome.driver","src/main/resources/chromedriver.exe");
		  driver = new ChromeDriver();
		  
		  driver.manage().window().maximize();	
		return driver;
		
	}
	
	public WebDriver getFireFoxDriver() {
		
		System.setProperty("webdriver.firefox.marionette","src/main/resources/geckodriver.exe");
		 driver = new FirefoxDriver();
		 
		  driver.manage().window().maximize();
		return driver;
		
	}
	
	public WebDriver getIEDriver() {
		return driver;	
	}
	
	
	public void closeDriver() {
		
		//driver.close();
		//driver.quit();
	}

}
