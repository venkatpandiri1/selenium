package com.eco.test;

import com.eco.base.BasePage;
import com.eco.utils.*;

import org.testng.Assert;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.eco.utils.AppProperties;
import java.util.Properties;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class EcoTestsNew {
	
		private WebDriver driver;
		private AppProperties appProp;
		public static Properties appProperties;
		public static WebDriverWait wait;
		public static boolean bresult = false;
		BasePage bp ;
		
		String timeStamp = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new Date());
		
		@BeforeTest
		public void initialise()
		{
			System.out.println("initialize");
			
		}
		
		@DataProvider(name = "Authentication")
		public static Object[][] credentials() throws IOException {
			
			System.out.println("test data provider credentials");
			 ExcelFileReader  exr = new ExcelFileReader();
			 Object[][] obj =  exr.ReadVariant();
	        return  obj;
	 
	     }
		

	  	@Test ( dataProvider = "Authentication")	 
		public void callToKeywords(String testcase , String steps , String keyword , String locator , String data) throws Exception
		{
			
	  		System.out.println("callToKeywords before switch");
			switch(keyword)
			{
				case "START_CHROME":
				{
					System.out.println(keyword);
					beforeTest(driver);
				}
			 break;
		/*	case "GOTO_URL":
				System.out.println(keyword);
				HomePage(driver);
				 break;*/
			case "SET_TEXT":				
				{
					System.out.println(keyword + "Data for set text =" + data + "locator name from excel = " + locator);
					bp.writeText(By.name(locator), data);
				}
			break;
			
				 
			case "SET_TEXT_BY_ID":					
			{
				System.out.println(keyword + "Data for set text =" + data + "locator name from excel = " + locator);
				bp.writeText(By.id(locator), data);
			}
			 break;
			 
			case "CLICK":
				{
					System.out.println(keyword + " locator = " + locator);
				    bp.click(By.id(locator));
				}
			break;
				 
			case "CLICK_BY_NAME":
			{
				System.out.println(keyword + " locator = " + locator);
			    bp.click(By.name(locator));
			}
			 break;
				 
			case "CLICK_BY_CLASS_NAME":
			{
				
				bp.clickClassname(By.cssSelector(locator), locator);
			   
			}
			break;
			 
			case "SELECT_ITEM_BY_ID":
			{
				System.out.println(keyword + " locator = " + locator);
				bp.selectItemInList(By.id(locator),locator, data);
			   
			}
			 break;
			 
			case "":
				System.out.println(keyword);
				 break;
				 
		    default:
					 break;
				 
			}
		}
				
		//@Test (priority =1)
		public void HomePage( WebDriver driver) {
			System.out.println("Entering home page method");
			Reporter.log(timeStamp + " Entering home page method."+ "<br>");
		    driver.get("http://www.google.com");
			
		   // driver.get("https://eco.test.att.com/uui/landing");
		    
		    wait = new WebDriverWait(driver, 30);
		  	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("login")));
		    wait = new WebDriverWait(driver, 30);
		    if(driver.findElements(By.id("login")).size() > 0) {
		    	Assert.assertTrue(true);
		    }
		    else Assert.assertTrue(false);
					
			System.out.println("End of the homepage method");
			Reporter.log(timeStamp + " End of the homepage method."+ "<br>");
		}		
	
		
	//	@Test (priority = 2 , dataProvider = "Authentication")
		public void login(String testcase , String Steps , String keyword, String locator, String value) {
			
			System.out.println("Entering login method");
			Reporter.log(timeStamp + " Entering login method."+ "<br>");
			System.out.println("testcaseid  = "+ testcase + " steps = " + Steps + "keyword = " + keyword +" locator = "+ locator +"value = " + value);
			
		    wait = new WebDriverWait(driver, 30);
		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("userid")));
		    
		    AppProperties ap = new AppProperties();
			Properties appProperties = ap.getProperties();
		    
		   
		   // System.out.println(appProperties.getProperty("username"));
		   	//System.out.println(appProperties.getProperty("password"));
		    	    
		   // driver.findElement(By.name("userid")).sendKeys(value);
		 //   driver.findElement(By.name("password")).sendKeys(value);
		 //   driver.findElement(By.name("btnSubmit")).click();
		    
		    //check for the success login screen
		 //   wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("srv_TitleMsg")));
		  
		//   if (driver.findElement(By.id("srv_TitleMsg")).getText().compareTo("Log On Successful") == 0)
		//   {
		//	   System.out.println("succesfully logged in");
		//   }
		   
		//    driver.findElement(By.name("successOK")).click();
		    
		//    wait = new WebDriverWait(driver, 10);
		//    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("module-header")));
		    
		//    if (driver.findElement(By.id("module-header")).getText().compareTo(" Deployment Pipeline") == 0) {
		//    	 {
		//  		   System.out.println("succesfully navigated to pipeline page in");
		//  	   }
		//    }
			    
		    
			System.out.println("End of the login method");
			Reporter.log(timeStamp + "End of the login method."+ "<br>");
		}
		
		
		/**
		 * create pipeline test
		 */
		
		
		@Test(priority = 3)
		public void createPipeline()
		{
			/*
			System.out.println("createPipeline");
			if (driver.findElements(By.className("btn btn-xs btn-primary pull-right createBtn")).size() > 0)
			{
				Reporter.log(timeStamp + "Found the create pipeline link."+ "<br>");
			}	*/		
		}
				
		
		@Test (priority = 10)
		public void exit() {
			System.out.println("Entering exit method");
			//WebDriver driver = new FirefoxDriver();
			//driver.get("http://www.google.com");
			driver.close();
			driver.quit();
			System.out.println("End of the exit method");
		}
		
		
		// @BeforeTest
		  public void beforeTest(WebDriver driver) throws Exception  {  
			  //Create chrome driver
			  try{
			 // System.out.println("Root folder = "+System.getProperty("user.dir"));
			  
			 System.setProperty("webdriver.chrome.driver", "C:\\Users\\vp1515\\Downloads\\chromedriver_win32\\chromedriver.exe");
			  driver = new ChromeDriver();
			  
			  getConfigurationData();
			  bp = new BasePage(driver);
			  driver.manage().window().maximize();	
			  driver.get("https://eco.test.att.com/uui/landing");
			  }
		  
		  catch(Exception ex)
		  {
			  System.out.println("Error is " + ex.toString());
		  }
		  
		}
		 
		 public void getConfigurationData() {
			  appProp = new AppProperties();
			  appProperties = appProp.getProperties();
			  //env =appProp.getProperty("username");
		 }
		  


}

 
 
 