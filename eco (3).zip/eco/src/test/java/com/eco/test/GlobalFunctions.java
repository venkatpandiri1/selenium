package com.eco.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class GlobalFunctions {
	
	
	public void Click(WebDriver driver ,String element , String Value  )
	{
		
		  driver.findElement(By.name(element)).sendKeys(Value);
	}

}
