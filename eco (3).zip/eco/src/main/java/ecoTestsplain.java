import org.testng.Assert;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.Select;
import com.eco.utils.AppProperties;
import java.util.Properties;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

	public class ecoTestsplain {
		
			private WebDriver driver;
			private AppProperties appProp;
			public static Properties appProperties;
			public static WebDriverWait wait;
			public static boolean bresult = false;
			
			String timeStamp = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new Date());
			
			@Test (priority =1)
			public void HomePage() {
				System.out.println("Entering home page method");
				Reporter.log(timeStamp + " Entering home page method."+ "<br>");
			    //driver.get("http://www.google.com");
			    driver.get("https://eco.test.att.com/uui/landing");
			    
			    wait = new WebDriverWait(driver, 30);
			  	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("login")));
			    wait = new WebDriverWait(driver, 30);
			    if(driver.findElements(By.id("login")).size() > 0) {
			    	Assert.assertTrue(true);
			    }
			    else Assert.assertTrue(false);
						
				System.out.println("End of the homepage method");
				Reporter.log(timeStamp + " End of the homepage method."+ "<br>");
			}
			
			
			@Test (priority = 2)
			public void login() {
				System.out.println("Entering login method");
				Reporter.log(timeStamp + " Entering login method."+ "<br>");
			    //driver.get("http://www.google.com");
			   
			    WebElement login = driver.findElement(By.id("login"));
			    login.click();
				
			    wait = new WebDriverWait(driver, 30);
			    wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("userid")));
			    
			    AppProperties ap = new AppProperties();
				Properties appProperties = ap.getProperties();
			    
			   
			    System.out.println(appProperties.getProperty("username"));
			   	System.out.println(appProperties.getProperty("password"));
			    	    
			    driver.findElement(By.name("userid")).sendKeys("vp1515");
			    driver.findElement(By.name("password")).sendKeys("Vamshi#1");
			    driver.findElement(By.name("btnSubmit")).click();
			    
			    //check for the success login screen
			    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("srv_TitleMsg")));
			  
			   if (driver.findElement(By.id("srv_TitleMsg")).getText().compareTo("Log On Successful") == 0)
			   {
				   System.out.println("succesfully logged in");
			   }
			   
			    driver.findElement(By.name("successOK")).click();
			    
			    wait = new WebDriverWait(driver, 10);
			    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("module-header")));
			    
			    if (driver.findElement(By.id("module-header")).getText().compareTo(" Deployment Pipeline") == 0) {
			    	 {
			  		   System.out.println("succesfully navigated to pipeline page in");
			  	   }
			    }
			    		    
			    
				System.out.println("End of the login method");
				Reporter.log(timeStamp + "End of the login method."+ "<br>");
			}
			
			
			/**
			 * create pipeline test
			 */
			
			
			@Test(priority = 3)
			public void createPipeline()
			{
				System.out.println("createPipeline start");
				 //By signInButtonBy = By.cssSelector(".createBtn");
				// wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(signInButtonBy));
				 wait = new WebDriverWait(driver, 120);
				 try {
					Thread.sleep(10000);
				
				 
				WebElement createPipeline = driver.findElement(By.cssSelector(".createBtn"));
				if (createPipeline.getText().contentEquals("Create Pipeline"))
				{
					createPipeline.click();
					Thread.sleep(2000);
					System.out.println("createPipeline  after click");
					driver.findElement(By.id("pipelineNameInput")).sendKeys("testing");
					Thread.sleep(500);
					driver.findElement(By.id("pipelineBranchInput")).sendKeys("master");
					Thread.sleep(100);
					if (driver.findElements(By.id("pipeline-create-menu")).size() > 0)
					{
						WebElement countryUL= driver.findElement(By.id("pipeline-create-menu"));
						List<WebElement> countriesList =countryUL.findElements(By.ByCssSelector.tagName("li"));	
						
						
						//List<WebElement> countriesList =countryUL.findElements(By.tagName("li"));
						System.out.println("size of ul is " + countriesList.size());
						for (WebElement li : countriesList) {
							System.out.println(li.getAttribute("innerText").trim());
							System.out.println("entered list");
							
							Thread.sleep(1000);
							
						if (li.getAttribute("innerText").trim().equals("CDP Workflow")) {
							System.out.println("fi condition");
						  //   li.click();
						   }
						}
						
						Select msCatalogOption = new Select(driver.findElement(By.id("msCatalogDropdown")));
						msCatalogOption.selectByValue("1a15daba-6f00-48e4-bb42-e28bbde2f516");
						Thread.sleep(200);
						driver.findElement(By.id("createPipelineSubmitBtn")).click();
						
						Thread.sleep(5000);
						//Select pipeLineType = new Select(driver.findElement(By.id("pipeline-create-menu")));
						//pipeLineType.selectByIndex(2);	
						Thread.sleep(5000);
								
					}
					Thread.sleep(1000);
					//driver.switchTo().frame("modal-title");
					
				}
				Thread.sleep(5000);
				
			
				
				 } catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
			}
			
			
			
			@Test (priority = 10)
			public void exit() {
				System.out.println("Entering exit method");
				//WebDriver driver = new FirefoxDriver();
				//driver.get("http://www.google.com");
				driver.close();
				driver.quit();
				System.out.println("End of the exit method");
			}
			
			
			 @BeforeTest
			  public void beforeTest() throws Exception  {  
				  //Create chrome driver
				  try{
				 // System.out.println("Root folder = "+System.getProperty("user.dir"));
				  
				 System.setProperty("webdriver.chrome.driver", "C:\\Users\\vp1515\\Downloads\\chromedriver_win32\\chromedriver.exe");
				  driver = new ChromeDriver();
				  driver.manage().window().maximize();	
				  getConfigurationData();
				  
				  }
			  
			  catch(Exception ex)
			  {
				  System.out.println("Error is " + ex.toString());
			  }

				  
			  
			  }
			 
			 public void getConfigurationData() {
				  appProp = new AppProperties();
				  appProperties = appProp.getProperties();
				  //env =appProp.getProperty("username");
			 }

	}

