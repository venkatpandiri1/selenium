package com.eco.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;

public class ExcelFileReader {

	 public static Object[][]  readXLSFileValues() throws IOException
		{
		 
			InputStream ExcelFileToRead = new FileInputStream("C://Users//vp1515//eclipse-workspace//eco//src//main//resources//ecoProjectTestData.xls");
			DataFormatter formatter = new DataFormatter();

			HSSFWorkbook  wb = new HSSFWorkbook(ExcelFileToRead);
			
			HSSFWorkbook test = new HSSFWorkbook(); 
			
			HSSFSheet sheet = wb.getSheetAt(0);
			HSSFRow row = sheet.getRow(0); ; 
		
			HSSFCell cell = null;
			
			
			int RowNum = sheet.getPhysicalNumberOfRows();// count my number of Rows
	        int ColNum= row.getLastCellNum(); // get last ColNum 
	         
	        Object Data[][]= new Object[RowNum-1][ColNum]; // pass my  count data in array
			
			//List<String> list = new ArrayList<String>();
			
			Iterator rows = sheet.rowIterator();
			int rowNum=0;
			while (rows.hasNext())
			{
				int colNum=0;
				row=(HSSFRow) rows.next();
				
				Iterator cells = row.cellIterator();
				
				
				if (rowNum > 1)
				{
				
				while (cells.hasNext())
				{
					
					cell=(HSSFCell) cells.next();
			
					if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING)
					{
						//System.out.print(cell.getStringCellValue()+" ");
					
						//	list.add(formatter.formatCellValue(cell));
						Data[rowNum][colNum]=formatter.formatCellValue(cell);
					}
					else if(cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
					{
						//System.out.print(cell.getNumericCellValue()+" ");
						Data[rowNum][colNum]=formatter.formatCellValue(cell);
						//	list.add(formatter.formatCellValue(cell));
					}
					else
					{
						//U Can Handel Boolean, Formula, Errors
					}								
					colNum++;					
				}
				
			}		
				rowNum++;
		}
			
			
			return Data;
		
		}
	
	 
	 public static Object[][] ReadVariant() throws IOException
	    {
		 
		 	DataFormatter formatter = new DataFormatter();
		 	FileInputStream fileInputStream= new FileInputStream("C://Users//vp1515//eclipse-workspace//eco//src//main//resources//ecoProjectTestData.xls"); //Excel sheet file location get mentioned here
	        HSSFWorkbook workbook = new HSSFWorkbook (fileInputStream); //get my workbook 
	        String SheetName;
	        HSSFSheet worksheet = workbook.getSheet("login");// get my sheet from workbook
	        HSSFRow Row=worksheet.getRow(0);     //get my Row which start from 0   
	     
	        int RowNum = worksheet.getPhysicalNumberOfRows();// count my number of Rows
	        int ColNum= Row.getLastCellNum(); // get last ColNum 
	         
	        Object Data[][]= new Object[RowNum-1][ColNum]; // pass my  count data in array
	         
	            for(int i=0; i<RowNum-1; i++) //Loop work for Rows
	            {  
	                HSSFRow row= worksheet.getRow(i+1);
	                 
	                for (int j=0; j<ColNum; j++) //Loop work for colNum
	                {
	                    if(row==null)
	                        Data[i][j]= "";
	                    else
	                    {
	                        HSSFCell cell= row.getCell(j);
	                        if(cell==null)
	                            Data[i][j]= ""; //if it get Null value it pass no data 
	                        else
	                        {
	                            String value=formatter.formatCellValue(cell);
	                            Data[i][j]=value; //This formatter get my all values as string i.e integer, float all type data value
	                           // System.out.println(value);
	                            
	                        }
	                    }
	                }
	            }
	 
	        return Data;
	    }
	 
	 
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		 //readXLSFileValues();
		 
		 ReadVariant();
	}

}
