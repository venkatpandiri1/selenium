package com.eco.utils;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Properties;


public class AppProperties {
				
	
		public Properties getProperties()
		{
			
			String filename = "config.properties";
			Properties prop = new Properties();
			InputStream input = null;
			
			System.out.println("getObjectProperties");
			try
			{
				input = getClass().getClassLoader().getResourceAsStream(filename);
	    		if(input==null)
	    		{
	    	         System.out.println("Sorry, unable to find " + filename);
	    		}
	    			
		    		//load a properties file from class path, inside static method
		    		prop.load(input);
	
	                //get the property value and print it out
	                //System.out.println(prop1.getProperty("environment"));
	    	        //System.out.println(prop1.getProperty("system"));
	    	        
			}
			catch(Exception ex)
			{
				 System.out.println(ex.getMessage());
			}
			return prop;
		}
		
		
		
	public Properties getObjectProperties()
	{
		
		String filename = "object.properties";
		Properties prop = new Properties();
		InputStream input = null;
		System.out.println("getObjectProperties");
		try
		{
			input = getClass().getClassLoader().getResourceAsStream(filename);
    		if(input==null)
    		{
    	         System.out.println("Sorry, unable to find " + filename);
    		}
    			
	    		//load a properties file from class path, inside static method
	    		prop.load(input);

                //get the property value and print it out
                //System.out.println(prop1.getProperty("environment"));
    	        //System.out.println(prop1.getProperty("system"));
    	        
		}
		catch(Exception ex)
		{
			 System.out.println(ex.getMessage());
		}
		return prop;
	}
		
}
