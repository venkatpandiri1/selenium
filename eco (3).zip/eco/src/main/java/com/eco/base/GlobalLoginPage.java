package com.eco.base;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class GlobalLoginPage extends BasePage{
	//*********Constructor*********
    public GlobalLoginPage(WebDriver driver) {
        super(driver);
    }
    
  //*********Web Elements*********
   By loginButtonBy2 = By.id("successOK");
  
  
   
   //?? what is this returning what is necessity
   public GlobalLoginPage loginToEcoHome (String username, String password){
      
      wait = new WebDriverWait(driver, 30);
      //click ok button
      click(loginButtonBy2);
       return this;
   }

}
