package com.eco.base;
//https://www.swtestacademy.com/page-object-model-java/

import org.openqa.selenium.By;
import java.util.Iterator;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


 
public class BasePage {
    public WebDriver driver;
    public WebDriverWait wait;
 
    //Constructor
    public BasePage (WebDriver driver){
        this.driver = driver;
        wait = new WebDriverWait(driver,30);
    }
 
    //Wait Wrapper Method
    public void waitVisibility(By elementBy) {
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(elementBy));
    }
 
    //Click Method
    public void click (By elementBy) {
    	System.out.println("click");
        waitVisibility(elementBy);
        driver.findElement(elementBy).click();
    }
    
    
  //Click Method by classname
    public void clickClassname (By elementBy, String locator) {
    	System.out.println("clickClassname" + "locator name = " + locator);
    	  wait = new WebDriverWait(driver,60);
        //waitVisibility(elementBy);
        try {
			Thread.sleep(10000);
			if (driver.findElements(By.cssSelector(".createBtn")).size() > 0)
			{
				List<WebElement> crButtons = driver.findElements(By.cssSelector(".createBtn"));
				Iterator<WebElement> iterator = crButtons.iterator();
				
				int index =0;
				while (iterator.hasNext()) 
				{
						index++;				
						// Iterate one by one
					    WebElement item = iterator.next();	
					    if (item.getText().equalsIgnoreCase("Create Pipeline"))
					    {
					    	if (item.isEnabled())
					    		item.click();
					    	else {
					    		if(item.isEnabled()) {
					    		Thread.sleep(4000);
					    		item.click();}
					    		else
					    			System.out.println("The Create Piepline control is not enabled");
					    		}
					    	break;
					    }
				}
			}
			
			} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
 
  //select item from list
    public void selectItemInList (By elementBy, String locator, String data) {
    	
        waitVisibility(elementBy);
        System.out.println("select item locator = " + locator);     
        Select msCatalogOption = new Select(driver.findElement(By.id(locator)));
    	msCatalogOption.selectByValue(data);
        
    }
   
    
    //Write Text
    public void writeText (By elementBy, String text) {
        waitVisibility(elementBy);
        System.out.println("sendkeys");
        driver.findElement(elementBy).sendKeys(text);
    }
 
    //Read Text
    public String readText (By elementBy) {
        waitVisibility(elementBy);
        System.out.println("readText");
        return driver.findElement(elementBy).getText();
    }
 
    
  
    
    //Assert
    public void assertEquals (By elementBy, String expectedText) {
        waitVisibility(elementBy);
        Assert.assertEquals(readText(elementBy), expectedText);
 
    }
}