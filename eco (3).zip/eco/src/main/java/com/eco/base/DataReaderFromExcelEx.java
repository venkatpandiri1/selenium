package com.eco.base;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.testng.annotations.DataProvider;

public class DataReaderFromExcelEx {
	
	private DataReaderFromExcelEx(){}
	
	@DataProvider(name = "basicDataProvider")
	 public synchronized static List<String> readXLSFile() throws IOException
		{
			InputStream ExcelFileToRead = new FileInputStream("src//main//resources//ecoProjectTestData.xls");
			DataFormatter formatter = new DataFormatter();

			HSSFWorkbook  wb = new HSSFWorkbook(ExcelFileToRead);
			
			HSSFWorkbook test = new HSSFWorkbook(); 
			
			HSSFSheet sheet = wb.getSheetAt(0);
			HSSFRow row; 
			HSSFCell cell = null;
			List<String> list = new ArrayList<String>();
			  
			Map<String, Object> hi = new HashMap<>(); 
			Iterator rows = sheet.rowIterator();
			int rowNum=0;
			while (rows.hasNext())
			{
				int colNum=0;
				row=(HSSFRow) rows.next();
				
				Iterator cells = row.cellIterator();
				
				if (rowNum > 0)
				{
				
				while (cells.hasNext())
				{
					cell=(HSSFCell) cells.next();
			
					if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING)
					{
						//System.out.print(cell.getStringCellValue()+" ");
						if(colNum == 1)
							list.add(formatter.formatCellValue(cell));
					}
					else if(cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
					{
						//System.out.print(cell.getNumericCellValue()+" ");
						if(colNum == 1)
							list.add(formatter.formatCellValue(cell));
					}
					else
					{
						//U Can Handel Boolean, Formula, Errors
					}
									
					colNum++;
					
				}
				
			}		
				rowNum++;
			}
			
			for(int i=0; i <list.size(); i++)
			{
				//System.out.println(list.get(i).toString());		
				
			}
			return (Object[][]) new Object();		
	}

	 public static List<String>  readXLSFileValues() throws IOException
		{
		 
			InputStream ExcelFileToRead = new FileInputStream("C://Users//vp1515//eclipse-workspace//eco//src//main//resources//ecoProjectTestData.xls");
			DataFormatter formatter = new DataFormatter();

			HSSFWorkbook  wb = new HSSFWorkbook(ExcelFileToRead);
			
			HSSFWorkbook test = new HSSFWorkbook(); 
			
			HSSFSheet sheet = wb.getSheetAt(0);
			HSSFRow row; 
			HSSFCell cell = null;
			List<String> list = new ArrayList<String>();
			  
			Iterator rows = sheet.rowIterator();
			int rowNum=0;
			while (rows.hasNext())
			{
				int colNum=0;
				row=(HSSFRow) rows.next();
				
				Iterator cells = row.cellIterator();
				
				if (rowNum > 0)
				{
				
				while (cells.hasNext())
				{
					cell=(HSSFCell) cells.next();
			
					if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING)
					{
						//System.out.print(cell.getStringCellValue()+" ");
						if(colNum == 2)
							list.add(formatter.formatCellValue(cell));
					}
					else if(cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
					{
						//System.out.print(cell.getNumericCellValue()+" ");
						if(colNum == 2)
							list.add(formatter.formatCellValue(cell));
					}
					else
					{
						//U Can Handel Boolean, Formula, Errors
					}								
					colNum++;					
				}
				
			}		
				rowNum++;
		}
			
			for(int i=0; i <list.size(); i++)
			{
				System.out.println(list.get(i).toString());		
				
			}
			return list;
		
		}
}
